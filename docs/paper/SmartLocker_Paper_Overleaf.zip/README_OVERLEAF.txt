========================================================================
SmartLocker Paper - Overleaf Project Package
Title: Smart Locker with Anomalous Access Detection Based on IoT Device Telemetry
Authors: Duc Hoang Nguyen* (duchoang.nguyen103@gmail.com, ORCID: 0009-0006-9780-8146),
         Viet Tien Nguyen, Huy Hoang Nguyen, Thanh Cao Nguyen, Thu Le, Kieu Trong Khanh
========================================================================

HOW TO USE IN OVERLEAF:
1. Log in to your Overleaf account (https://www.overleaf.com).
2. Click 'New Project' -> 'Upload Project'.
3. Select 'SmartLocker_Paper_Overleaf.zip' and upload.
4. Settings:
   - Compiler: XeLaTeX or LuaLaTeX (recommended for fontspec) or pdfLaTeX
   - TeX Live version: 2023 / 2024 (any modern version)
   - Main document: main.tex
5. Click 'Recompile'. The PDF will be compiled cleanly with all figures,
   correct TeX Gyre fonts, and complete references with DOIs!
